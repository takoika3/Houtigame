# 星剣と魔導書のクロニクル

HTML・CSS・JavaScriptだけで動作する、放置型ファンタジーRPGのプロトタイプです。

## 主な機能

- オートバトルとステージ進行
- 剣士・魔導士・狩人
- スキルローテーション
- 三系統・15ノードの星魂スキルツリー
- 複数ランク、前提条件、相互排他キーストーン
- 転生と恒久強化
- R / SR / SSRガチャ
- オフライン放置報酬
- localStorageによる自動セーブ
- レスポンシブUI

## ローカルで遊ぶ

`index.html`をブラウザで開くだけです。

ローカルサーバーを使う場合:

```bash
python3 -m http.server 8000
```

その後、ブラウザで `http://localhost:8000` を開きます。

## GitHubへ公開する

```bash
git init
git add .
git commit -m "Initial release"
git branch -M main
git remote add origin https://github.com/YOUR_NAME/YOUR_REPOSITORY.git
git push -u origin main
```

GitHubリポジトリの `Settings` → `Pages` → `Build and deployment` → `Source` で **GitHub Actions** を選択してください。

`main`ブランチへpushすると、`.github/workflows/pages.yml`が静的ゲームをGitHub Pagesへ公開します。

## ファイル構成

```text
.
├── .github/workflows/pages.yml
├── .gitignore
├── .nojekyll
├── index.html
├── style.css
├── game.js
├── LICENSE
└── README.md
```

## セーブデータ

セーブはブラウザのlocalStorageに保存されます。ブラウザや端末を変えると共有されません。

## ライセンス

MIT License
